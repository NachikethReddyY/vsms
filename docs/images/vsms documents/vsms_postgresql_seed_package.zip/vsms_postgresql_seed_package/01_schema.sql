BEGIN;

CREATE SCHEMA IF NOT EXISTS vsms;

CREATE TABLE IF NOT EXISTS vsms.participants (
    participant_code varchar(20) PRIMARY KEY,
    full_name varchar(100) NOT NULL,
    gender varchar(20),
    date_of_birth date,
    phone varchar(30),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.events (
    event_id varchar(20) PRIMARY KEY,
    event_name varchar(100) NOT NULL,
    event_date date NOT NULL,
    location varchar(150),
    organizer varchar(100),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.stations (
    station_id varchar(10) PRIMARY KEY,
    station_name varchar(100) NOT NULL,
    test_type varchar(50) NOT NULL,
    station_order integer NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS vsms.screeners (
    screener_id varchar(20) PRIMARY KEY,
    full_name varchar(100) NOT NULL,
    role varchar(50) NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS vsms.screening_rule_sets (
    rule_set_id bigserial PRIMARY KEY,
    rule_code varchar(50) NOT NULL,
    rule_version varchar(30) NOT NULL,
    test_type varchar(50) NOT NULL,
    rule_definition jsonb NOT NULL,
    status varchar(20) NOT NULL DEFAULT 'DRAFT',
    effective_from timestamptz,
    effective_to timestamptz,
    created_by varchar(50) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_rule_version UNIQUE(rule_code, rule_version),
    CONSTRAINT chk_rule_status CHECK(status IN ('DRAFT','ACTIVE','RETIRED')),
    CONSTRAINT chk_rule_json_object CHECK(jsonb_typeof(rule_definition)='object')
);

CREATE TABLE IF NOT EXISTS vsms.screening_results (
    screening_id varchar(50) PRIMARY KEY,
    participant_code varchar(20) NOT NULL REFERENCES vsms.participants(participant_code),
    event_id varchar(20) NOT NULL REFERENCES vsms.events(event_id),
    station_id varchar(10) NOT NULL REFERENCES vsms.stations(station_id),
    screener_id varchar(20) NOT NULL REFERENCES vsms.screeners(screener_id),
    screener_name varchar(100) NOT NULL,
    test_results jsonb NOT NULL,
    observations jsonb NOT NULL DEFAULT '{}'::jsonb,
    device_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    overall_flag varchar(10) NOT NULL,
    explanation text NOT NULL,
    notes text,
    rule_version varchar(30) NOT NULL,
    sync_status varchar(20) NOT NULL DEFAULT 'SYNCED',
    screened_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT chk_flag CHECK(overall_flag IN ('GREEN','AMBER','RED')),
    CONSTRAINT chk_sync_status CHECK(sync_status IN ('PENDING','SYNCED','FAILED')),
    CONSTRAINT chk_test_results_object CHECK(jsonb_typeof(test_results)='object'),
    CONSTRAINT uq_participant_event_station UNIQUE(participant_code,event_id,station_id)
);

CREATE TABLE IF NOT EXISTS vsms.rule_evaluations (
    evaluation_id bigserial PRIMARY KEY,
    screening_id varchar(50) NOT NULL REFERENCES vsms.screening_results(screening_id) ON DELETE CASCADE,
    rule_code varchar(50) NOT NULL,
    rule_version varchar(30) NOT NULL,
    input_snapshot jsonb NOT NULL,
    evaluation_result jsonb NOT NULL,
    evaluated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.sync_queue (
    sync_id bigserial PRIMARY KEY,
    local_record_id varchar(80) NOT NULL UNIQUE,
    participant_code varchar(20) NOT NULL,
    station_id varchar(10) NOT NULL,
    payload jsonb NOT NULL,
    sync_status varchar(20) NOT NULL DEFAULT 'PENDING',
    retry_count integer NOT NULL DEFAULT 0,
    last_error text,
    created_at timestamptz NOT NULL DEFAULT now(),
    synced_at timestamptz,
    CONSTRAINT chk_sync_queue_status CHECK(sync_status IN ('PENDING','SYNCED','FAILED'))
);

CREATE INDEX IF NOT EXISTS idx_screening_results_participant
ON vsms.screening_results(participant_code, screened_at DESC);

CREATE INDEX IF NOT EXISTS idx_screening_results_event
ON vsms.screening_results(event_id, station_id);

CREATE INDEX IF NOT EXISTS idx_screening_results_flag
ON vsms.screening_results(overall_flag, screened_at DESC);

CREATE INDEX IF NOT EXISTS idx_screening_results_test_results_gin
ON vsms.screening_results
USING gin(test_results jsonb_path_ops);

CREATE INDEX IF NOT EXISTS idx_left_eye_rank
ON vsms.screening_results(
    ((test_results #>> '{visualAcuity,leftEye,rank}')::integer)
)
WHERE test_results ? 'visualAcuity';

CREATE INDEX IF NOT EXISTS idx_colour_result
ON vsms.screening_results(
    (test_results #>> '{colourVision,result}')
)
WHERE test_results ? 'colourVision';

COMMIT;
