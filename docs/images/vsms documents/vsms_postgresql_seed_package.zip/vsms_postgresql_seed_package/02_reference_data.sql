BEGIN;

INSERT INTO vsms.participants(participant_code,full_name,gender,date_of_birth,phone)
VALUES
('P10021','Tan Ah Meng','M','1985-05-12','90000021'),
('P10022','Siti Aisyah','F','1990-08-21','90000022'),
('P10023','Kumar Raj','M','1978-11-03','90000023'),
('P10024','Lim Wei Ling','F','1995-02-17','90000024'),
('P10025','Ali Bin Hassan','M','1969-07-30','90000025')
ON CONFLICT(participant_code) DO NOTHING;

INSERT INTO vsms.events(event_id,event_name,event_date,location,organizer)
VALUES
('EVT001','Healthy Eyes 2026','2026-07-15','Community Hall A','VSMS Team'),
('EVT002','Community Care Screening','2026-08-15','Kampung Hall','Community Health'),
('EVT003','Senior Health Day','2026-10-05','Town Clinic','Senior Care Network')
ON CONFLICT(event_id) DO NOTHING;

INSERT INTO vsms.stations(station_id,station_name,test_type,station_order)
VALUES
('ST01','Visual Acuity','VISUAL_ACUITY',1),
('ST02','Colour Vision','COLOUR_VISION',2),
('ST03','Near Vision','NEAR_VISION',3),
('ST04','Contrast Sensitivity','CONTRAST_SENSITIVITY',4),
('ST05','Stereo Vision','STEREO_VISION',5),
('ST06','Eye Alignment','EYE_ALIGNMENT',6)
ON CONFLICT(station_id) DO NOTHING;

INSERT INTO vsms.screeners(screener_id,full_name,role)
VALUES
('SCR001','Alice Tan','Screener'),
('SCR002','Daniel Chong','Technician'),
('SCR003','Aisha Rahman','Optometrist')
ON CONFLICT(screener_id) DO NOTHING;

COMMIT;
