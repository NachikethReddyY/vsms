BEGIN;

INSERT INTO vsms.screening_rule_sets(
  rule_code,rule_version,test_type,rule_definition,status,effective_from,created_by
)
VALUES
(
  'VISUAL_ACUITY_ADULT','VSMS-1.0','VISUAL_ACUITY',
  '{
    "rules":[
      {"priority":10,"condition":{"field":"visualAcuity.leftEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":4},"flag":"RED","reasonCode":"LEFT_EYE_REDUCED"},
      {"priority":20,"condition":{"field":"visualAcuity.rightEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":4},"flag":"RED","reasonCode":"RIGHT_EYE_REDUCED"},
      {"priority":30,"condition":{"field":"visualAcuity.leftEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":3},"flag":"AMBER","reasonCode":"LEFT_EYE_REVIEW"},
      {"priority":40,"condition":{"field":"visualAcuity.rightEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":3},"flag":"AMBER","reasonCode":"RIGHT_EYE_REVIEW"}
    ],
    "defaultResult":{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE"}
  }'::jsonb,
  'ACTIVE','2026-07-01T00:00:00+08:00','ADMIN001'
),
(
  'COLOUR_VISION_STANDARD','VSMS-1.0','COLOUR_VISION',
  '{
    "rules":[
      {"priority":10,"condition":{"field":"colourVision.result","operator":"EQUALS","value":"FAIL"},"flag":"RED","reasonCode":"COLOUR_VISION_FAIL"},
      {"priority":20,"condition":{"field":"colourVision.result","operator":"EQUALS","value":"REVIEW"},"flag":"AMBER","reasonCode":"COLOUR_VISION_REVIEW"}
    ],
    "defaultResult":{"flag":"GREEN","reasonCode":"COLOUR_VISION_PASS"}
  }'::jsonb,
  'ACTIVE','2026-07-01T00:00:00+08:00','ADMIN001'
)
ON CONFLICT(rule_code,rule_version) DO NOTHING;

COMMIT;
