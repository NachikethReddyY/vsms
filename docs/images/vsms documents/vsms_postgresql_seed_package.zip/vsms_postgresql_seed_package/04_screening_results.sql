BEGIN;

INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST01','P10021','EVT001','ST01','SCR001','Alice Tan',
 '{"visualAcuity":{"leftEye":{"display":"6/12","rank":3},"rightEye":{"display":"6/6","rank":1},"withCorrection":true}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Left-eye acuity matched the configured follow-up threshold.','Participant uses glasses.',
 'VSMS-1.0','SYNCED','2026-07-15T13:00:15+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST02','P10021','EVT001','ST02','SCR002','Daniel Chong',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":14,"result":"PASS"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST02","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Colour-vision score is within the configured screening range.','Completed all plates.',
 'VSMS-1.0','SYNCED','2026-07-15T13:05:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST03','P10021','EVT001','ST03','SCR001','Alice Tan',
 '{"nearVision":{"leftEye":"N6","rightEye":"N6","binocular":"N6"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST03","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Near-vision values are within the configured range.','No discomfort reported.',
 'VSMS-1.0','SYNCED','2026-07-15T13:10:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST04','P10021','EVT001','ST04','SCR002','Daniel Chong',
 '{"contrastSensitivity":{"test":"PELLI_ROBSON","score":1.5,"unit":"logCS","result":"BORDERLINE"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST04","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Contrast score matched the configured review threshold.','Repeat test recommended.',
 'VSMS-1.0','SYNCED','2026-07-15T13:15:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0002-ST01','P10022','EVT001','ST01','SCR001','Alice Tan',
 '{"visualAcuity":{"leftEye":{"display":"6/6","rank":1},"rightEye":{"display":"6/6","rank":1},"withCorrection":false}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Visual acuity is within the configured screening range.','No correction used.',
 'VSMS-1.0','SYNCED','2026-07-15T13:20:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0002-ST02','P10022','EVT001','ST02','SCR002','Daniel Chong',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":10,"result":"FAIL"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST02","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'RED','Colour-vision result matched the configured referral threshold.','Refer for further assessment.',
 'VSMS-1.0','SYNCED','2026-07-15T13:25:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0003-ST01','P10023','EVT001','ST01','SCR003','Aisha Rahman',
 '{"visualAcuity":{"leftEye":{"display":"6/18","rank":4},"rightEye":{"display":"6/12","rank":3},"withCorrection":true}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'RED','Left-eye acuity matched the configured referral threshold.','Comprehensive eye examination recommended.',
 'VSMS-1.0','SYNCED','2026-07-15T13:30:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0004-ST05','P10024','EVT001','ST05','SCR003','Aisha Rahman',
 '{"stereoVision":{"test":"RANDOT","arcSeconds":40,"result":"PASS"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST05","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Stereo-vision result is within the configured screening range.','Completed successfully.',
 'VSMS-1.0','SYNCED','2026-07-15T13:35:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0005-ST06','P10025','EVT001','ST06','SCR003','Aisha Rahman',
 '{"eyeAlignment":{"alignment":"EXO","coverTest":"REVIEW","result":"REVIEW"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST06","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Eye-alignment result requires review.','Follow-up recommended.',
 'VSMS-1.0','PENDING','2026-07-15T13:40:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;

COMMIT;
