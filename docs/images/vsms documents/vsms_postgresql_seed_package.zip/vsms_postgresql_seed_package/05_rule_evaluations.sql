BEGIN;

INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/12","rank":3},"rightEye":{"display":"6/6","rank":1},"withCorrection":true}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:00:15+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST02',
 'COLOUR_VISION_STANDARD',
 'VSMS-1.0',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":14,"result":"PASS"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:05:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST03',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"nearVision":{"leftEye":"N6","rightEye":"N6","binocular":"N6"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:10:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST04',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"contrastSensitivity":{"test":"PELLI_ROBSON","score":1.5,"unit":"logCS","result":"BORDERLINE"}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:15:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0002-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/6","rank":1},"rightEye":{"display":"6/6","rank":1},"withCorrection":false}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:20:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0002-ST02',
 'COLOUR_VISION_STANDARD',
 'VSMS-1.0',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":10,"result":"FAIL"}}'::jsonb,
 '{"flag":"RED","reasonCode":"REFERRAL_REQUIRED","matchedRules":[],"clientFlag":"RED","flagMismatch":false}'::jsonb,
 '2026-07-15T13:25:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0003-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/18","rank":4},"rightEye":{"display":"6/12","rank":3},"withCorrection":true}}'::jsonb,
 '{"flag":"RED","reasonCode":"REFERRAL_REQUIRED","matchedRules":[],"clientFlag":"RED","flagMismatch":false}'::jsonb,
 '2026-07-15T13:30:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0004-ST05',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"stereoVision":{"test":"RANDOT","arcSeconds":40,"result":"PASS"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:35:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0005-ST06',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"eyeAlignment":{"alignment":"EXO","coverTest":"REVIEW","result":"REVIEW"}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:40:00+08:00'::timestamptz
);

COMMIT;
