BEGIN;

INSERT INTO vsms.sync_queue(
  local_record_id,participant_code,station_id,payload,sync_status,retry_count,created_at
)
VALUES
(
  'local-20260715-0001',
  'P10025',
  'ST06',
  '{
    "participantCode":"P10025",
    "eventId":"EVT001",
    "stationId":"ST06",
    "screenerId":"SCR003",
    "testResults":{
      "eyeAlignment":{
        "alignment":"EXO",
        "coverTest":"REVIEW",
        "result":"REVIEW"
      }
    },
    "syncStatus":"PENDING"
  }'::jsonb,
  'PENDING',
  0,
  '2026-07-15T13:40:00+08:00'
)
ON CONFLICT(local_record_id) DO NOTHING;

COMMIT;
