-- 1. Count rows by table
SELECT 'participants' AS table_name, count(*) FROM vsms.participants
UNION ALL
SELECT 'events', count(*) FROM vsms.events
UNION ALL
SELECT 'stations', count(*) FROM vsms.stations
UNION ALL
SELECT 'screeners', count(*) FROM vsms.screeners
UNION ALL
SELECT 'screening_results', count(*) FROM vsms.screening_results
UNION ALL
SELECT 'rule_evaluations', count(*) FROM vsms.rule_evaluations
UNION ALL
SELECT 'sync_queue', count(*) FROM vsms.sync_queue;

-- 2. Same participant across multiple stations
SELECT
  participant_code,
  event_id,
  station_id,
  overall_flag,
  screened_at
FROM vsms.screening_results
WHERE participant_code='P10021'
ORDER BY screened_at;

-- 3. Extract left-eye acuity
SELECT
  screening_id,
  participant_code,
  test_results #>> '{visualAcuity,leftEye,display}' AS left_eye,
  (test_results #>> '{visualAcuity,leftEye,rank}')::integer AS left_eye_rank
FROM vsms.screening_results
WHERE test_results ? 'visualAcuity';

-- 4. Find colour-vision failures
SELECT
  screening_id,
  participant_code,
  test_results #>> '{colourVision,result}' AS result
FROM vsms.screening_results
WHERE test_results @> '{"colourVision":{"result":"FAIL"}}'::jsonb;

-- 5. Count by overall flag
SELECT overall_flag, count(*) AS total
FROM vsms.screening_results
GROUP BY overall_flag
ORDER BY overall_flag;

-- 6. Pending offline sync records
SELECT local_record_id, participant_code, station_id, sync_status, retry_count
FROM vsms.sync_queue
WHERE sync_status='PENDING';

-- 7. Latest screening by participant
SELECT DISTINCT ON (participant_code)
  participant_code,
  screening_id,
  station_id,
  overall_flag,
  screened_at
FROM vsms.screening_results
ORDER BY participant_code, screened_at DESC;
