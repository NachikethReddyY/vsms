BEGIN;
TRUNCATE TABLE
  vsms.rule_evaluations,
  vsms.sync_queue,
  vsms.screening_results,
  vsms.screening_rule_sets,
  vsms.screeners,
  vsms.stations,
  vsms.events,
  vsms.participants
RESTART IDENTITY CASCADE;
COMMIT;
