# VSMS PostgreSQL Seed Package

## Files

1. `01_schema.sql`  
   Creates the `vsms` schema, tables, constraints, and JSONB indexes.

2. `02_reference_data.sql`  
   Seeds participants, events, stations, and screeners.

3. `03_rule_sets.sql`  
   Seeds versioned JSONB rule definitions.

4. `04_screening_results.sql`  
   Seeds multi-station screening results using `test_results JSONB`.

5. `05_rule_evaluations.sql`  
   Seeds audit records for rule evaluation.

6. `06_sync_queue.sql`  
   Seeds one offline IndexedDB-style pending synchronization record.

7. `07_verify_queries.sql`  
   Contains verification and teaching queries.

8. `99_reset.sql`  
   Deletes all seeded data and resets identities.

## Run order

```bash
psql -U postgres -d visual_screening -f 01_schema.sql
psql -U postgres -d visual_screening -f 02_reference_data.sql
psql -U postgres -d visual_screening -f 03_rule_sets.sql
psql -U postgres -d visual_screening -f 04_screening_results.sql
psql -U postgres -d visual_screening -f 05_rule_evaluations.sql
psql -U postgres -d visual_screening -f 06_sync_queue.sql
psql -U postgres -d visual_screening -f 07_verify_queries.sql
```

Or run the combined script:

```bash
psql -U postgres -d visual_screening -f seed_all.sql
```

## Seeded scenarios

- Same participant across multiple stations
- GREEN, AMBER, and RED results
- Visual acuity, colour vision, near vision, contrast sensitivity, stereo vision, and eye alignment
- Versioned rule definitions
- Rule-evaluation audit trail
- Pending offline synchronization record
