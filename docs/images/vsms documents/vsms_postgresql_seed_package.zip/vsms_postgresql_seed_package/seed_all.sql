BEGIN;

CREATE SCHEMA IF NOT EXISTS vsms;

CREATE TABLE IF NOT EXISTS vsms.participants (
    participant_code varchar(20) PRIMARY KEY,
    full_name varchar(100) NOT NULL,
    gender varchar(20),
    date_of_birth date,
    phone varchar(30),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.events (
    event_id varchar(20) PRIMARY KEY,
    event_name varchar(100) NOT NULL,
    event_date date NOT NULL,
    location varchar(150),
    organizer varchar(100),
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.stations (
    station_id varchar(10) PRIMARY KEY,
    station_name varchar(100) NOT NULL,
    test_type varchar(50) NOT NULL,
    station_order integer NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS vsms.screeners (
    screener_id varchar(20) PRIMARY KEY,
    full_name varchar(100) NOT NULL,
    role varchar(50) NOT NULL,
    active boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS vsms.screening_rule_sets (
    rule_set_id bigserial PRIMARY KEY,
    rule_code varchar(50) NOT NULL,
    rule_version varchar(30) NOT NULL,
    test_type varchar(50) NOT NULL,
    rule_definition jsonb NOT NULL,
    status varchar(20) NOT NULL DEFAULT 'DRAFT',
    effective_from timestamptz,
    effective_to timestamptz,
    created_by varchar(50) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_rule_version UNIQUE(rule_code, rule_version),
    CONSTRAINT chk_rule_status CHECK(status IN ('DRAFT','ACTIVE','RETIRED')),
    CONSTRAINT chk_rule_json_object CHECK(jsonb_typeof(rule_definition)='object')
);

CREATE TABLE IF NOT EXISTS vsms.screening_results (
    screening_id varchar(50) PRIMARY KEY,
    participant_code varchar(20) NOT NULL REFERENCES vsms.participants(participant_code),
    event_id varchar(20) NOT NULL REFERENCES vsms.events(event_id),
    station_id varchar(10) NOT NULL REFERENCES vsms.stations(station_id),
    screener_id varchar(20) NOT NULL REFERENCES vsms.screeners(screener_id),
    screener_name varchar(100) NOT NULL,
    test_results jsonb NOT NULL,
    observations jsonb NOT NULL DEFAULT '{}'::jsonb,
    device_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    overall_flag varchar(10) NOT NULL,
    explanation text NOT NULL,
    notes text,
    rule_version varchar(30) NOT NULL,
    sync_status varchar(20) NOT NULL DEFAULT 'SYNCED',
    screened_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT chk_flag CHECK(overall_flag IN ('GREEN','AMBER','RED')),
    CONSTRAINT chk_sync_status CHECK(sync_status IN ('PENDING','SYNCED','FAILED')),
    CONSTRAINT chk_test_results_object CHECK(jsonb_typeof(test_results)='object'),
    CONSTRAINT uq_participant_event_station UNIQUE(participant_code,event_id,station_id)
);

CREATE TABLE IF NOT EXISTS vsms.rule_evaluations (
    evaluation_id bigserial PRIMARY KEY,
    screening_id varchar(50) NOT NULL REFERENCES vsms.screening_results(screening_id) ON DELETE CASCADE,
    rule_code varchar(50) NOT NULL,
    rule_version varchar(30) NOT NULL,
    input_snapshot jsonb NOT NULL,
    evaluation_result jsonb NOT NULL,
    evaluated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS vsms.sync_queue (
    sync_id bigserial PRIMARY KEY,
    local_record_id varchar(80) NOT NULL UNIQUE,
    participant_code varchar(20) NOT NULL,
    station_id varchar(10) NOT NULL,
    payload jsonb NOT NULL,
    sync_status varchar(20) NOT NULL DEFAULT 'PENDING',
    retry_count integer NOT NULL DEFAULT 0,
    last_error text,
    created_at timestamptz NOT NULL DEFAULT now(),
    synced_at timestamptz,
    CONSTRAINT chk_sync_queue_status CHECK(sync_status IN ('PENDING','SYNCED','FAILED'))
);

CREATE INDEX IF NOT EXISTS idx_screening_results_participant
ON vsms.screening_results(participant_code, screened_at DESC);

CREATE INDEX IF NOT EXISTS idx_screening_results_event
ON vsms.screening_results(event_id, station_id);

CREATE INDEX IF NOT EXISTS idx_screening_results_flag
ON vsms.screening_results(overall_flag, screened_at DESC);

CREATE INDEX IF NOT EXISTS idx_screening_results_test_results_gin
ON vsms.screening_results
USING gin(test_results jsonb_path_ops);

CREATE INDEX IF NOT EXISTS idx_left_eye_rank
ON vsms.screening_results(
    ((test_results #>> '{visualAcuity,leftEye,rank}')::integer)
)
WHERE test_results ? 'visualAcuity';

CREATE INDEX IF NOT EXISTS idx_colour_result
ON vsms.screening_results(
    (test_results #>> '{colourVision,result}')
)
WHERE test_results ? 'colourVision';

COMMIT;


BEGIN;

INSERT INTO vsms.participants(participant_code,full_name,gender,date_of_birth,phone)
VALUES
('P10021','Tan Ah Meng','M','1985-05-12','90000021'),
('P10022','Siti Aisyah','F','1990-08-21','90000022'),
('P10023','Kumar Raj','M','1978-11-03','90000023'),
('P10024','Lim Wei Ling','F','1995-02-17','90000024'),
('P10025','Ali Bin Hassan','M','1969-07-30','90000025')
ON CONFLICT(participant_code) DO NOTHING;

INSERT INTO vsms.events(event_id,event_name,event_date,location,organizer)
VALUES
('EVT001','Healthy Eyes 2026','2026-07-15','Community Hall A','VSMS Team'),
('EVT002','Community Care Screening','2026-08-15','Kampung Hall','Community Health'),
('EVT003','Senior Health Day','2026-10-05','Town Clinic','Senior Care Network')
ON CONFLICT(event_id) DO NOTHING;

INSERT INTO vsms.stations(station_id,station_name,test_type,station_order)
VALUES
('ST01','Visual Acuity','VISUAL_ACUITY',1),
('ST02','Colour Vision','COLOUR_VISION',2),
('ST03','Near Vision','NEAR_VISION',3),
('ST04','Contrast Sensitivity','CONTRAST_SENSITIVITY',4),
('ST05','Stereo Vision','STEREO_VISION',5),
('ST06','Eye Alignment','EYE_ALIGNMENT',6)
ON CONFLICT(station_id) DO NOTHING;

INSERT INTO vsms.screeners(screener_id,full_name,role)
VALUES
('SCR001','Alice Tan','Screener'),
('SCR002','Daniel Chong','Technician'),
('SCR003','Aisha Rahman','Optometrist')
ON CONFLICT(screener_id) DO NOTHING;

COMMIT;


BEGIN;

INSERT INTO vsms.screening_rule_sets(
  rule_code,rule_version,test_type,rule_definition,status,effective_from,created_by
)
VALUES
(
  'VISUAL_ACUITY_ADULT','VSMS-1.0','VISUAL_ACUITY',
  '{
    "rules":[
      {"priority":10,"condition":{"field":"visualAcuity.leftEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":4},"flag":"RED","reasonCode":"LEFT_EYE_REDUCED"},
      {"priority":20,"condition":{"field":"visualAcuity.rightEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":4},"flag":"RED","reasonCode":"RIGHT_EYE_REDUCED"},
      {"priority":30,"condition":{"field":"visualAcuity.leftEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":3},"flag":"AMBER","reasonCode":"LEFT_EYE_REVIEW"},
      {"priority":40,"condition":{"field":"visualAcuity.rightEye.rank","operator":"GREATER_THAN_OR_EQUAL","value":3},"flag":"AMBER","reasonCode":"RIGHT_EYE_REVIEW"}
    ],
    "defaultResult":{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE"}
  }'::jsonb,
  'ACTIVE','2026-07-01T00:00:00+08:00','ADMIN001'
),
(
  'COLOUR_VISION_STANDARD','VSMS-1.0','COLOUR_VISION',
  '{
    "rules":[
      {"priority":10,"condition":{"field":"colourVision.result","operator":"EQUALS","value":"FAIL"},"flag":"RED","reasonCode":"COLOUR_VISION_FAIL"},
      {"priority":20,"condition":{"field":"colourVision.result","operator":"EQUALS","value":"REVIEW"},"flag":"AMBER","reasonCode":"COLOUR_VISION_REVIEW"}
    ],
    "defaultResult":{"flag":"GREEN","reasonCode":"COLOUR_VISION_PASS"}
  }'::jsonb,
  'ACTIVE','2026-07-01T00:00:00+08:00','ADMIN001'
)
ON CONFLICT(rule_code,rule_version) DO NOTHING;

COMMIT;


BEGIN;

INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST01','P10021','EVT001','ST01','SCR001','Alice Tan',
 '{"visualAcuity":{"leftEye":{"display":"6/12","rank":3},"rightEye":{"display":"6/6","rank":1},"withCorrection":true}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Left-eye acuity matched the configured follow-up threshold.','Participant uses glasses.',
 'VSMS-1.0','SYNCED','2026-07-15T13:00:15+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST02','P10021','EVT001','ST02','SCR002','Daniel Chong',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":14,"result":"PASS"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST02","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Colour-vision score is within the configured screening range.','Completed all plates.',
 'VSMS-1.0','SYNCED','2026-07-15T13:05:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST03','P10021','EVT001','ST03','SCR001','Alice Tan',
 '{"nearVision":{"leftEye":"N6","rightEye":"N6","binocular":"N6"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST03","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Near-vision values are within the configured range.','No discomfort reported.',
 'VSMS-1.0','SYNCED','2026-07-15T13:10:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0001-ST04','P10021','EVT001','ST04','SCR002','Daniel Chong',
 '{"contrastSensitivity":{"test":"PELLI_ROBSON","score":1.5,"unit":"logCS","result":"BORDERLINE"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST04","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Contrast score matched the configured review threshold.','Repeat test recommended.',
 'VSMS-1.0','SYNCED','2026-07-15T13:15:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0002-ST01','P10022','EVT001','ST01','SCR001','Alice Tan',
 '{"visualAcuity":{"leftEye":{"display":"6/6","rank":1},"rightEye":{"display":"6/6","rank":1},"withCorrection":false}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Visual acuity is within the configured screening range.','No correction used.',
 'VSMS-1.0','SYNCED','2026-07-15T13:20:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0002-ST02','P10022','EVT001','ST02','SCR002','Daniel Chong',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":10,"result":"FAIL"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST02","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'RED','Colour-vision result matched the configured referral threshold.','Refer for further assessment.',
 'VSMS-1.0','SYNCED','2026-07-15T13:25:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0003-ST01','P10023','EVT001','ST01','SCR003','Aisha Rahman',
 '{"visualAcuity":{"leftEye":{"display":"6/18","rank":4},"rightEye":{"display":"6/12","rank":3},"withCorrection":true}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST01","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'RED','Left-eye acuity matched the configured referral threshold.','Comprehensive eye examination recommended.',
 'VSMS-1.0','SYNCED','2026-07-15T13:30:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0004-ST05','P10024','EVT001','ST05','SCR003','Aisha Rahman',
 '{"stereoVision":{"test":"RANDOT","arcSeconds":40,"result":"PASS"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST05","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'GREEN','Stereo-vision result is within the configured screening range.','Completed successfully.',
 'VSMS-1.0','SYNCED','2026-07-15T13:35:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;


INSERT INTO vsms.screening_results(
 screening_id,participant_code,event_id,station_id,screener_id,screener_name,
 test_results,observations,device_metadata,overall_flag,explanation,notes,
 rule_version,sync_status,screened_at
)
VALUES(
 'SCR20260715-0005-ST06','P10025','EVT001','ST06','SCR003','Aisha Rahman',
 '{"eyeAlignment":{"alignment":"EXO","coverTest":"REVIEW","result":"REVIEW"}}'::jsonb,
 '{"symptoms":[]}'::jsonb,
 '{"deviceId":"TABLET-ST06","appVersion":"1.2.0","platform":"Android"}'::jsonb,
 'AMBER','Eye-alignment result requires review.','Follow-up recommended.',
 'VSMS-1.0','PENDING','2026-07-15T13:40:00+08:00'::timestamptz
)
ON CONFLICT(screening_id) DO NOTHING;

COMMIT;


BEGIN;

INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/12","rank":3},"rightEye":{"display":"6/6","rank":1},"withCorrection":true}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:00:15+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST02',
 'COLOUR_VISION_STANDARD',
 'VSMS-1.0',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":14,"result":"PASS"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:05:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST03',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"nearVision":{"leftEye":"N6","rightEye":"N6","binocular":"N6"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:10:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0001-ST04',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"contrastSensitivity":{"test":"PELLI_ROBSON","score":1.5,"unit":"logCS","result":"BORDERLINE"}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:15:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0002-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/6","rank":1},"rightEye":{"display":"6/6","rank":1},"withCorrection":false}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:20:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0002-ST02',
 'COLOUR_VISION_STANDARD',
 'VSMS-1.0',
 '{"colourVision":{"test":"ISHIHARA","platesPresented":14,"correctAnswers":10,"result":"FAIL"}}'::jsonb,
 '{"flag":"RED","reasonCode":"REFERRAL_REQUIRED","matchedRules":[],"clientFlag":"RED","flagMismatch":false}'::jsonb,
 '2026-07-15T13:25:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0003-ST01',
 'VISUAL_ACUITY_ADULT',
 'VSMS-1.0',
 '{"visualAcuity":{"leftEye":{"display":"6/18","rank":4},"rightEye":{"display":"6/12","rank":3},"withCorrection":true}}'::jsonb,
 '{"flag":"RED","reasonCode":"REFERRAL_REQUIRED","matchedRules":[],"clientFlag":"RED","flagMismatch":false}'::jsonb,
 '2026-07-15T13:30:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0004-ST05',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"stereoVision":{"test":"RANDOT","arcSeconds":40,"result":"PASS"}}'::jsonb,
 '{"flag":"GREEN","reasonCode":"WITHIN_SCREENING_RANGE","matchedRules":[],"clientFlag":"GREEN","flagMismatch":false}'::jsonb,
 '2026-07-15T13:35:00+08:00'::timestamptz
);


INSERT INTO vsms.rule_evaluations(
 screening_id,rule_code,rule_version,input_snapshot,evaluation_result,evaluated_at
)
VALUES(
 'SCR20260715-0005-ST06',
 'STATION_GENERIC_RULE',
 'VSMS-1.0',
 '{"eyeAlignment":{"alignment":"EXO","coverTest":"REVIEW","result":"REVIEW"}}'::jsonb,
 '{"flag":"AMBER","reasonCode":"REVIEW_REQUIRED","matchedRules":[],"clientFlag":"AMBER","flagMismatch":false}'::jsonb,
 '2026-07-15T13:40:00+08:00'::timestamptz
);

COMMIT;


BEGIN;

INSERT INTO vsms.sync_queue(
  local_record_id,participant_code,station_id,payload,sync_status,retry_count,created_at
)
VALUES
(
  'local-20260715-0001',
  'P10025',
  'ST06',
  '{
    "participantCode":"P10025",
    "eventId":"EVT001",
    "stationId":"ST06",
    "screenerId":"SCR003",
    "testResults":{
      "eyeAlignment":{
        "alignment":"EXO",
        "coverTest":"REVIEW",
        "result":"REVIEW"
      }
    },
    "syncStatus":"PENDING"
  }'::jsonb,
  'PENDING',
  0,
  '2026-07-15T13:40:00+08:00'
)
ON CONFLICT(local_record_id) DO NOTHING;

COMMIT;
